#include "cards.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
	srand(time(0));
	Deck d;
	//Card c;
	//for (int i = 0; i < 52; i++) {
	//	c = d.deal();
	//	cout << c.str() << endl;
	//}

	for (int i = 0; i < 10; i++) {
		Card c1 = d.deal();
		Card c2 = d.deal();
		if (c1.eq(c2))
			cout << c1.str() << " equals " << c2.str() << endl;
		else if (c1.gt(c2))
			cout << c1.str() << " greater than " << c2.str() << endl;
		else
			cout << c1.str() << " less than " << c2.str() << endl;
	}

	system("pause");
	return 0;
}
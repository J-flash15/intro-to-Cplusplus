#pragma once

#include <string>

class Card {
private:
	int suit_index, value_index;
public:
	Card();
	Card(int card_index);

	char suit() const;
	char value() const;
	std::string str() const;

	bool eq(const Card& c) const { return value_index == c.value_index; }
	bool gt(const Card& c) const { return value_index > c.value_index; }
};

class Deck {
private:
	Card cards[52];
	int used_count;
public:
	Deck();
	Card deal();
	void shuffle();
	int size() const { return 52 - used_count; }
};
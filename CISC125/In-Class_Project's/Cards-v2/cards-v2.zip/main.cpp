#include "cards.h"
#include <iostream>
#include <cstdlib>
#include <ctime>
using namespace std;

int main() {
	srand(time(0));
	Deck d;

	//for (int i = 0; i < 10; i++) {
	//	Card c1 = d.deal();
	//	Card c2 = d.deal();
	//	if (c1 == c2)
	//		cout << c1 << " equals " << c2 << endl;
	//	else if (c1 > c2)
	//		cout << c1 << " greater than " << c2 << endl;
	//	else
	//		cout << c1 << " less than " << c2 << endl;
	//}

	Hand hand1;
	Hand hand2;
	// Add 5 cards to hand1.
	for (int i = 0; i < 5; i++)
		hand1.insert(d.deal());
	// Add 7 cards to hand2.
	for (int i = 0; i < 7; i++)
		hand2.insert(d.deal());
	cout << hand1 << endl;
	cout << hand2 << endl;

	system("pause");
	return 0;
}
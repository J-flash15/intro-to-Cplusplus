#pragma once

#include <iostream>
#include <string>

class Card {
private:
	int suit_index, value_index;
public:
	Card();
	Card(int card_index);

	char suit() const;
	char value() const;
	std::string str() const;

	bool eq(const Card& c) const { return value_index == c.value_index; }
	bool ne(const Card& c) const { return value_index != c.value_index; }
	bool gt(const Card& c) const { return value_index > c.value_index; }
	bool ge(const Card& c) const { return value_index >= c.value_index; }
	bool lt(const Card& c) const { return value_index < c.value_index; }
	bool le(const Card& c) const { return value_index <= c.value_index; }
};

static bool operator== (const Card& c1, const Card& c2) { return c1.eq(c2); }
static bool operator!= (const Card& c1, const Card& c2) { return c1.ne(c2); }
static bool operator> (const Card& c1, const Card& c2) { return c1.gt(c2); }
static bool operator>= (const Card& c1, const Card& c2) { return c1.ge(c2); }
static bool operator< (const Card& c1, const Card& c2) { return c1.lt(c2); }
static bool operator<= (const Card& c1, const Card& c2) { return c1.le(c2); }

std::ostream& operator<< (std::ostream& os, const Card& c);

class Deck {
private:
	Card cards[52];
	int used_count;
public:
	Deck();
	Card deal();
	void shuffle();
	int size() const { return 52 - used_count; }
};

class Hand {
private:
	Card cards[52];
	int cards_count;
public:
	Hand() { cards_count = 0; }
	Card card(int n) const { return cards[n]; }
	void clear() { cards_count = 0; }
	void insert(const Card& c) { cards[cards_count++] = c; }
	int size() const { return cards_count; }
	std::string str() const;
};

std::ostream& operator<< (std::ostream& os, const Hand& h);